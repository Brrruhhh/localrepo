#!/usr/bin/env python3

import os
import sys
import json
import subprocess
import threading
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS

app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)

# Global variables
deployment_in_progress = False
deployment_status = "idle"
deployment_logs = []

def log_deployment(message):
    """Add message to deployment logs"""
    global deployment_logs
    deployment_logs.append(message)
    print(message)

def docker_cli(*args):
    """Execute docker command via CLI"""
    try:
        result = subprocess.run(['docker'] + list(args), 
                              capture_output=True, text=True, timeout=30)
        return result.returncode, result.stdout, result.stderr
    except Exception as e:
        return 1, "", str(e)

# ==================== API ENDPOINTS ====================

@app.route('/')
def index():
    """Serve the frontend"""
    return render_template('index.html')

@app.route('/network-test')
def network_test_page():
    """Serve the network test page"""
    return render_template('network_test.html')

@app.route('/api/status', methods=['GET'])
def get_status():
    """Get overall system status"""
    try:
        # Get container list from Docker CLI
        code, stdout, stderr = docker_cli('ps', '--format', '{{json .}}')
        
        if code != 0:
            return jsonify({
                'status': 'error',
                'message': 'Docker not available',
                'containers': [],
                'container_count': 0,
                'deployment_status': deployment_status,
                'deployment_in_progress': deployment_in_progress
            }), 500
        
        containers = []
        for line in stdout.strip().split('\n'):
            if line:
                try:
                    cont = json.loads(line)
                    # Filter for our containers only
                    name = cont.get('Names', '')
                    if any(pattern in name for pattern in ['web-server', 'db-server', 'email-server', 'client-pc']):
                        containers.append({
                            'name': name,
                            'status': cont.get('State', 'unknown'),
                            'image': cont.get('Image', 'unknown'),
                            'id': cont.get('ID', '')[:12]
                        })
                except json.JSONDecodeError:
                    continue
        
        return jsonify({
            'status': 'running' if not deployment_in_progress else 'deploying',
            'deployment_status': deployment_status,
            'deployment_in_progress': deployment_in_progress,
            'containers': containers,
            'container_count': len(containers)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/deployment/status', methods=['GET'])
def get_deployment_status():
    """Get deployment status"""
    return jsonify({
        'status': deployment_status,
        'in_progress': deployment_in_progress,
        'logs': deployment_logs[-50:]  # Last 50 log entries
    }), 200

@app.route('/api/deploy', methods=['POST'])
def deploy():
    """Deploy the entire infrastructure"""
    global deployment_in_progress, deployment_status
    
    if deployment_in_progress:
        return jsonify({'error': 'Deployment already in progress'}), 400
    
    deployment_in_progress = True
    deployment_logs.clear()
    
    # Start deployment in background thread
    thread = threading.Thread(target=deploy_in_background)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'message': 'Deployment started',
        'status': 'deploying'
    }), 202

def deploy_infrastructure_cli():
    """Deploy infrastructure using pure Docker CLI commands"""
    try:
        log_deployment("📡 Creating docker networks...")
        docker_cli('network', 'create', 'frontend_net', '--driver', 'bridge')
        docker_cli('network', 'create', 'backend_net', '--driver', 'bridge')
        log_deployment("✅ Networks created")
        
        # Deploy web server
        log_deployment("🌐 Deploying web-server-1...")
        docker_cli('run', '-d', '--name', 'web-server-1', 
                  '--network', 'frontend_net',
                  '-p', '8080:80',
                  '--restart', 'unless-stopped',
                  'nginx:alpine')
        log_deployment("✅ web-server-1 deployed")
        
        # Deploy database server
        log_deployment("🗄️ Deploying db-server-1...")
        docker_cli('run', '-d', '--name', 'db-server-1',
                  '--network', 'backend_net',
                  '-e', 'MYSQL_ROOT_PASSWORD=root123',
                  '-e', 'MYSQL_DATABASE=cms_db',
                  '--restart', 'unless-stopped',
                  'mysql:8.0')
        log_deployment("✅ db-server-1 deployed")
        
        # Deploy email server - needs to be on BOTH networks for client access
        log_deployment("📧 Deploying email-server-1...")
        docker_cli('run', '-d', '--name', 'email-server-1',
                  '--network', 'backend_net',
                  '-p', '25:25',  # Expose port 25
                  '--restart', 'unless-stopped',
                  'ubuntu:22.04', 'bash', '-c', 
                  'apt-get update -qq && apt-get install -y postfix mailutils curl iputils-ping net-tools telnet && service postfix start && tail -f /dev/null')
        log_deployment("✅ email-server-1 deployed with postfix")
        
        # Deploy client PCs with networking tools
        for i in range(1, 4):
            name = f"client-pc-{i}"
            log_deployment(f"🖥️ Deploying {name}...")
            docker_cli('run', '-d', '--name', name,
                      '--network', 'frontend_net',  # Clients on frontend network
                      '--restart', 'unless-stopped',
                      'ubuntu:22.04', 'bash', '-c',
                      'apt-get update -qq && apt-get install -y curl iputils-ping net-tools telnet && tail -f /dev/null')
            log_deployment(f"✅ {name} deployed with networking tools")
        
        log_deployment("⏳ Waiting 10 seconds for containers to stabilize...")
        import time
        time.sleep(10)
        
        # Connect services to both networks as needed
        log_deployment("🔗 Connecting containers to networks...")
        # Web server to backend for database
        docker_cli('network', 'connect', 'backend_net', 'web-server-1')
        # Email server to frontend for client access
        docker_cli('network', 'connect', 'frontend_net', 'email-server-1')
        log_deployment("✅ Network connectivity configured")
        
        # Test postfix startup
        log_deployment("📧 Verifying email server...")
        docker_cli('exec', 'email-server-1', 'service', 'postfix', 'status')
        log_deployment("✅ Postfix verified")
        
        log_deployment("✅ Infrastructure deployment completed successfully!")
        return True
        
    except Exception as e:
        log_deployment(f"❌ Deployment failed: {str(e)}")
        import traceback
        log_deployment(traceback.format_exc())
        return False

def deploy_in_background():
    """Deploy infrastructure in background"""
    global deployment_status, deployment_in_progress
    
    try:
        deployment_status = "deploying"
        log_deployment("🚀 Starting infrastructure deployment...")
        
        # Clean up existing containers first
        log_deployment("🧹 Cleaning up existing containers...")
        code, stdout, stderr = docker_cli('ps', '-a', '--format', '{{.Names}}')
        for line in stdout.split('\n'):
            if any(p in line for p in ['web-server', 'db-server', 'email-server', 'client-pc']):
                docker_cli('stop', line)
                docker_cli('rm', line)
        log_deployment("✅ Cleanup complete")
        
        # Deploy using pure CLI
        if deploy_infrastructure_cli():
            deployment_status = "completed"
        else:
            deployment_status = "failed"
            
    except Exception as e:
        log_deployment(f"❌ Deployment error: {str(e)}")
        deployment_status = "failed"
        import traceback
        log_deployment(traceback.format_exc())
    finally:
        deployment_in_progress = False

@app.route('/api/create-client', methods=['POST'])
def create_client():
    """Create a new client container"""
    try:
        # Get next client number
        code, stdout, stderr = docker_cli('ps', '-a', '--format', '{{.Names}}')
        
        client_count = 0
        for line in stdout.split('\n'):
            if 'client-pc-' in line:
                try:
                    num = int(line.split('-')[-1])
                    client_count = max(client_count, num)
                except:
                    pass
        
        next_number = client_count + 1
        final_name = f"client-pc-{next_number}"
        
        log_deployment(f"🐳 Creating new client: {final_name}")
        
        # Deploy new client using docker run
        code, stdout, stderr = docker_cli('run', '-d', '--name', final_name, 
                                         'ubuntu:22.04', 'tail', '-f', '/dev/null')
        
        if code == 0:
            log_deployment(f"✅ Client {final_name} created successfully")
            container_id = stdout.strip()[:12]
            return jsonify({
                'message': f'Client {final_name} created successfully',
                'container': {
                    'name': final_name,
                    'id': container_id,
                    'status': 'running'
                }
            }), 201
        else:
            raise Exception(stderr)
        
    except Exception as e:
        log_deployment(f"❌ Failed to create client: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/stop-container/<container_name>', methods=['POST'])
def stop_container(container_name):
    """Stop a specific container"""
    try:
        log_deployment(f"🛑 Stopping container: {container_name}")
        
        code, stdout, stderr = docker_cli('stop', container_name)
        
        if code == 0:
            log_deployment(f"✅ Container {container_name} stopped successfully")
            return jsonify({
                'message': f'Container {container_name} stopped successfully',
                'container': {
                    'name': container_name,
                    'status': 'stopped'
                }
            }), 200
        else:
            raise Exception(stderr)
        
    except Exception as e:
        log_deployment(f"❌ Failed to stop container: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/start-container/<container_name>', methods=['POST'])
def start_container(container_name):
    """Start a stopped container"""
    try:
        log_deployment(f"▶️ Starting container: {container_name}")
        
        code, stdout, stderr = docker_cli('start', container_name)
        
        if code == 0:
            log_deployment(f"✅ Container {container_name} started successfully")
            return jsonify({
                'message': f'Container {container_name} started successfully',
                'container': {
                    'name': container_name,
                    'status': 'running'
                }
            }), 200
        else:
            raise Exception(stderr)
        
    except Exception as e:
        log_deployment(f"❌ Failed to start container: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/remove-container/<container_name>', methods=['DELETE'])
def remove_container(container_name):
    """Remove a container"""
    try:
        log_deployment(f"🗑️ Removing container: {container_name}")
        
        # Stop if running
        docker_cli('stop', container_name)
        # Remove
        code, stdout, stderr = docker_cli('rm', container_name)
        
        if code == 0:
            log_deployment(f"✅ Container {container_name} removed successfully")
            return jsonify({
                'message': f'Container {container_name} removed successfully'
            }), 200
        else:
            raise Exception(stderr)
        
    except Exception as e:
        log_deployment(f"❌ Failed to remove container: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/cleanup', methods=['POST'])
def cleanup():
    """Cleanup all infrastructure"""
    try:
        log_deployment("🗑️ Cleaning up all infrastructure...")
        
        # Stop all our containers
        code, stdout, stderr = docker_cli('ps', '--format', '{{.Names}}')
        
        count = 0
        for line in stdout.split('\n'):
            if any(p in line for p in ['web-server', 'db-server', 'email-server', 'client-pc']):
                docker_cli('stop', line)
                docker_cli('rm', line)
                count += 1
        
        log_deployment(f"✅ Removed {count} containers")
        return jsonify({
            'message': f'Infrastructure cleaned up successfully ({count} containers removed)'
        }), 200
        
    except Exception as e:
        log_deployment(f"❌ Cleanup failed: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/security-audit', methods=['GET'])
def security_audit():
    """Run security audit"""
    try:
        log_deployment("🔒 Running security audit...")
        
        # Get container details and check for security issues
        code, stdout, stderr = docker_cli('ps', '--format', '{{json .}}')
        
        issues = []
        if code == 0:
            for line in stdout.split('\n'):
                if line:
                    try:
                        cont = json.loads(line)
                        # Basic security checks
                        if 'root' in cont.get('User', ''):
                            issues.append(f"Container {cont.get('Names')} running as root")
                    except:
                        pass
        
        log_deployment(f"✅ Security audit completed ({len(issues)} issues found)")
        
        return jsonify({
            'message': 'Security audit completed',
            'issues': issues if issues else ['All containers passed security checks']
        }), 200
        
    except Exception as e:
        log_deployment(f"❌ Security audit failed: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/harden-security', methods=['POST'])
def harden_security():
    """Apply security hardening to containers"""
    global deployment_in_progress
    
    if deployment_in_progress:
        return jsonify({'error': 'Operation in progress. Please wait.'}), 400
    
    deployment_in_progress = True
    deployment_logs.clear()
    
    # Start hardening in background thread
    thread = threading.Thread(target=harden_security_background)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'message': 'Security hardening started',
        'status': 'hardening'
    }), 202

def harden_security_background():
    """Apply security hardening in background"""
    global deployment_in_progress
    
    try:
        log_deployment("🔐 Starting security hardening...")
        
        # Get container list
        code, stdout, stderr = docker_cli('ps', '--format', '{{json .}}')
        if code != 0:
            log_deployment("❌ Could not get container list")
            return
        
        containers = []
        for line in stdout.strip().split('\n'):
            if line:
                try:
                    cont = json.loads(line)
                    name = cont.get('Names', '')
                    if any(p in name for p in ['web-server', 'db-server', 'email-server', 'client-pc']):
                        containers.append(name)
                except:
                    continue
        
        log_deployment(f"🛡️ Hardening {len(containers)} containers...")
        
        for container in containers:
            log_deployment(f"\n🔒 Securing {container}...")
            
            # Install security tools
            log_deployment(f"  📦 Installing security tools...")
            docker_cli('exec', container, 'sh', '-c', 
                      'apt-get update && apt-get install -y curl netcat-openbsd openssh-client 2>/dev/null || true')
            docker_cli('exec', container, 'sh', '-c', 
                      'apk add --no-cache curl netcat-openbsd openssh-client 2>/dev/null || true')
            
            log_deployment(f"  ✅ {container} hardened")
        
        log_deployment("\n✅ Security hardening completed!")
        
    except Exception as e:
        log_deployment(f"❌ Hardening failed: {str(e)}")
    finally:
        deployment_in_progress = False

# ==================== NETWORK TESTING ====================

connectivity_results = []
connectivity_in_progress = False
connectivity_stats = {
    'total': 0,
    'passed': 0,
    'failed': 0
}

@app.route('/api/test-connectivity', methods=['POST'])
def test_connectivity_endpoint():
    """Start connectivity tests"""
    global connectivity_in_progress, connectivity_results, connectivity_stats
    
    if connectivity_in_progress:
        return jsonify({'status': 'already_running'}), 400
    
    connectivity_in_progress = True
    connectivity_results = []
    connectivity_stats = {'total': 0, 'passed': 0, 'failed': 0}
    
    # Start testing in background thread
    thread = threading.Thread(target=run_connectivity_tests)
    thread.daemon = True
    thread.start()
    
    return jsonify({'status': 'started'}), 202

def test_port_connectivity(source_container, target_host, port, timeout=10):
    """Test if a port is accessible from source container to target"""
    try:
        cmd = f'timeout {timeout} bash -c "</dev/tcp/{target_host}/{port}" 2>/dev/null && echo "OK" || echo "FAILED"'
        code, stdout, stderr = docker_cli('exec', source_container, 'bash', '-c', cmd)
        return 'OK' in stdout
    except:
        return False

def run_connectivity_tests():
    """Run all connectivity tests"""
    global connectivity_in_progress, connectivity_results, connectivity_stats
    
    try:
        # Get list of containers
        code, stdout, stderr = docker_cli('ps', '--format', '{{.Names}}')
        if code != 0:
            connectivity_results.append("❌ Could not get container list")
            connectivity_in_progress = False
            return
        
        all_containers = [c.strip() for c in stdout.split('\n') if c.strip()]
        containers = {
            'clients': [c for c in all_containers if 'client-pc' in c],
            'web': [c for c in all_containers if 'web-server' in c],
            'db': [c for c in all_containers if 'db-server' in c],
            'email': [c for c in all_containers if 'email-server' in c]
        }
        
        connectivity_results.append("🔍 Starting network connectivity tests...")
        connectivity_results.append(f"📊 Testing {len(all_containers)} containers...")
        
        # Test 1: Client to Web Server (Port 80)
        if containers['clients'] and containers['web']:
            connectivity_results.append("🌐 Testing Client -> Web Server (Port 80)...")
            web_server = containers['web'][0]
            for client in containers['clients']:
                connectivity_stats['total'] += 1
                if test_port_connectivity(client, web_server, 80):
                    connectivity_results.append(f"✅ {client} -> {web_server}:80 - SUCCESS")
                    connectivity_stats['passed'] += 1
                else:
                    connectivity_results.append(f"❌ {client} -> {web_server}:80 - FAILED")
                    connectivity_stats['failed'] += 1
        
        # Test 2: Client to Email Server (Port 25)
        if containers['clients'] and containers['email']:
            connectivity_results.append("📧 Testing Client -> Email Server (Port 25)...")
            email_server = containers['email'][0]
            for client in containers['clients']:
                connectivity_stats['total'] += 1
                if test_port_connectivity(client, email_server, 25):
                    connectivity_results.append(f"✅ {client} -> {email_server}:25 - SUCCESS")
                    connectivity_stats['passed'] += 1
                else:
                    connectivity_results.append(f"❌ {client} -> {email_server}:25 - FAILED")
                    connectivity_stats['failed'] += 1
        
        # Test 3: Web Server to Database (Port 3306)
        if containers['web'] and containers['db']:
            connectivity_results.append("🗄️ Testing Web Server -> Database (Port 3306)...")
            db_server = containers['db'][0]
            web_server = containers['web'][0]
            connectivity_stats['total'] += 1
            if test_port_connectivity(web_server, db_server, 3306):
                connectivity_results.append(f"✅ {web_server} -> {db_server}:3306 - SUCCESS")
                connectivity_stats['passed'] += 1
            else:
                connectivity_results.append(f"❌ {web_server} -> {db_server}:3306 - FAILED")
                connectivity_stats['failed'] += 1
        
        # Test 4: Email Server to Database (Port 3306)
        if containers['email'] and containers['db']:
            connectivity_results.append("📧 Testing Email Server -> Database (Port 3306)...")
            db_server = containers['db'][0]
            email_server = containers['email'][0]
            connectivity_stats['total'] += 1
            if test_port_connectivity(email_server, db_server, 3306):
                connectivity_results.append(f"✅ {email_server} -> {db_server}:3306 - SUCCESS")
                connectivity_stats['passed'] += 1
            else:
                connectivity_results.append(f"❌ {email_server} -> {db_server}:3306 - FAILED")
                connectivity_stats['failed'] += 1
        
        # Test 5: Client to Client Ping
        if len(containers['clients']) > 1:
            connectivity_results.append("🖥️ Testing Client -> Client Communication...")
            connectivity_results.append(f"Testing ping between {len(containers['clients'])} clients...")
            for i, source in enumerate(containers['clients']):
                for target in containers['clients'][i+1:]:
                    connectivity_stats['total'] += 1
                    try:
                        code, stdout, stderr = docker_cli('exec', source, 'ping', '-c', '1', target)
                        if code == 0:
                            connectivity_results.append(f"✅ {source} -> {target} - PING SUCCESS")
                            connectivity_stats['passed'] += 1
                        else:
                            connectivity_results.append(f"❌ {source} -> {target} - PING FAILED")
                            connectivity_stats['failed'] += 1
                    except:
                        connectivity_results.append(f"❌ {source} -> {target} - PING ERROR")
                        connectivity_stats['failed'] += 1
        
        connectivity_results.append("\n✅ Network testing completed!")
        
    except Exception as e:
        connectivity_results.append(f"❌ Testing error: {str(e)}")
        import traceback
        connectivity_results.append(traceback.format_exc())
    finally:
        connectivity_in_progress = False

@app.route('/api/connectivity-results', methods=['GET'])
def get_connectivity_results():
    """Get connectivity test results"""
    return jsonify({
        'results': connectivity_results,
        'completed': not connectivity_in_progress,
        'stats': connectivity_stats,
        'system_info': {
            'containers_running': len(connectivity_results) if connectivity_results else 0,
            'networks': 2,
            'duration': 'calculating...'
        },
        'issues': []
    }), 200

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({'error': 'Server error'}), 500

if __name__ == '__main__':
    print("🚀 Initializing CMS API...")
    
    # Check Docker is available
    code, stdout, stderr = docker_cli('--version')
    if code == 0:
        print(f"✅ Docker is available")
    else:
        print(f"⚠️ Warning: Docker not available")
    
    print("✅ API initialized successfully")
    print("🌐 Starting Flask server...")
    app.run(debug=True, host='0.0.0.0', port=5000)
