#!/usr/bin/env python3
"""
Enhanced CMS API with versioning, health checks, and deployment management
"""

import os
import sys
import json
import docker
import threading
import time
import requests
import subprocess
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add cms directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'cms'))

from cms.main import CentralManagementSystem
from cms.config_manager import ConfigManager

app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)

# Global variables
cms = None
deployment_in_progress = False
deployment_status = "idle"
deployment_logs = []

def init_cms():
    """Initialize the CMS system"""
    global cms
    try:
        cms = CentralManagementSystem()
        print("✅ CMS initialized successfully")
        return True
    except Exception as e:
        print(f"⚠️ Warning: Error initializing CMS: {e}")
        return False

def log_deployment(message):
    """Add message to deployment logs"""
    global deployment_logs
    deployment_logs.append(message)
    print(message)

# ==================== DEPLOYMENT ENDPOINTS ====================

@app.route('/api/status', methods=['GET'])
def get_status():
    """Get overall system status"""
    try:
        if cms is None:
            return jsonify({'status': 'error', 'message': 'CMS not initialized'}), 500
        
        containers = cms.docker_client.containers.list(all=True)
        managed_containers = [c for c in containers if any(p in c.name for p in ['web-server-', 'db-server-', 'email-server-', 'client-pc-'])]
        
        container_status = []
        for container in managed_containers:
            container_status.append({
                'name': container.name,
                'status': container.status,
                'image': container.image.tags[0] if container.image.tags else 'unknown',
                'id': container.id[:12]
            })
        
        return jsonify({
            'status': 'ok',
            'deployment_status': deployment_status,
            'deployment_in_progress': deployment_in_progress,
            'containers': container_status,
            'container_count': len(container_status)
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/deployment/status', methods=['GET'])
def get_deployment_status():
    """Get deployment status and logs"""
    return jsonify({
        'status': deployment_status,
        'in_progress': deployment_in_progress,
        'logs': deployment_logs[-100:]
    }), 200

@app.route('/api/deploy', methods=['POST'])
def deploy():
    """Deploy infrastructure"""
    global deployment_in_progress, deployment_status
    
    if deployment_in_progress:
        return jsonify({'error': 'Deployment already in progress'}), 400
    
    if cms is None:
        return jsonify({'error': 'CMS not initialized'}), 503
    
    deployment_in_progress = True
    deployment_logs.clear()
    
    thread = threading.Thread(target=deploy_in_background)
    thread.daemon = True
    thread.start()
    
    return jsonify({'message': 'Deployment started', 'status': 'deploying'}), 202

def deploy_in_background():
    """Deploy in background"""
    global deployment_in_progress, deployment_status
    
    try:
        deployment_status = "deploying"
        log_deployment("🚀 Starting infrastructure deployment...")
        
        cms.deploy_infrastructure()
        
        deployment_status = "completed"
        log_deployment("✅ Infrastructure deployment completed!")
    except Exception as e:
        deployment_status = "failed"
        log_deployment(f"❌ Deployment failed: {str(e)}")
    finally:
        deployment_in_progress = False

# ==================== HEALTH CHECK ENDPOINTS ====================

@app.route('/api/health', methods=['GET'])
def get_health():
    """Get system health status"""
    try:
        if cms is None:
            return jsonify({'status': 'error', 'message': 'CMS not initialized'}), 500
        
        health_stats = cms.get_system_health()
        return jsonify(health_stats), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health/check', methods=['POST'])
def check_health():
    """Run immediate health check"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        health_report = cms.health_monitor.check_all_containers()
        return jsonify(health_report), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== DEPLOYMENT HISTORY & VERSIONING ====================

@app.route('/api/deployments', methods=['GET'])
def get_deployments():
    """Get deployment history"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        limit = request.args.get('limit', 10, type=int)
        history = cms.get_deployment_history(limit)
        
        return jsonify({
            'deployments': history,
            'count': len(history)
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/deployment/<deployment_id>', methods=['GET'])
def get_deployment(deployment_id):
    """Get specific deployment details"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        deployment = cms.deployment_manager.get_deployment(deployment_id)
        if not deployment:
            return jsonify({'error': 'Deployment not found'}), 404
        
        return jsonify(deployment), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/deployment/<deployment_id>/rollback', methods=['POST'])
def rollback_deployment(deployment_id):
    """Rollback to specific deployment"""
    global deployment_in_progress
    
    if deployment_in_progress:
        return jsonify({'error': 'Deployment operation in progress'}), 400
    
    if cms is None:
        return jsonify({'error': 'CMS not initialized'}), 503
    
    deployment_in_progress = True
    deployment_logs.clear()
    
    thread = threading.Thread(target=rollback_in_background, args=(deployment_id,))
    thread.daemon = True
    thread.start()
    
    return jsonify({'message': 'Rollback started', 'deployment_id': deployment_id}), 202

def rollback_in_background(deployment_id):
    """Rollback in background"""
    global deployment_in_progress
    
    try:
        log_deployment(f"🔄 Starting rollback to {deployment_id}...")
        cms.rollback_to_deployment(deployment_id)
        log_deployment("✅ Rollback completed!")
    except Exception as e:
        log_deployment(f"❌ Rollback failed: {str(e)}")
    finally:
        deployment_in_progress = False

# ==================== CONFIGURATION MANAGEMENT ====================

@app.route('/api/configuration', methods=['GET'])
def get_configuration():
    """Get current configuration"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        config_export = cms.config_manager.export_config('json')
        if config_export:
            return json.loads(config_export), 200
        return jsonify({'error': 'Failed to export config'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/configuration/validate', methods=['POST'])
def validate_configuration():
    """Validate configuration"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        config_data = request.get_json()
        is_valid = cms.config_manager.validate_config(config_data)
        
        return jsonify({
            'valid': is_valid,
            'message': 'Configuration is valid' if is_valid else 'Configuration validation failed'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/configuration/versions', methods=['GET'])
def get_configuration_versions():
    """Get configuration version history"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        versions = cms.config_manager.list_versions()
        return jsonify({'versions': versions}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/configuration/check-changes', methods=['GET'])
def check_config_changes():
    """Check if configuration has changed"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        has_changes = cms.check_config_for_changes()
        return jsonify({
            'has_changes': has_changes,
            'message': 'Configuration has changed' if has_changes else 'No changes detected'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== SECURITY ENDPOINTS ====================

@app.route('/api/security/audit', methods=['POST'])
def security_audit():
    """Run security audit"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        log_deployment("🔒 Running security audit...")
        audit_results = cms.security_audit()
        log_deployment("✅ Security audit completed")
        
        return jsonify({
            'message': 'Security audit completed',
            'audit_results': audit_results
        }), 200
    except Exception as e:
        log_deployment(f"❌ Audit failed: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/security/harden', methods=['POST'])
def harden_security():
    """Apply security hardening"""
    global deployment_in_progress
    
    if deployment_in_progress:
        return jsonify({'error': 'Operation in progress'}), 400
    
    if cms is None:
        return jsonify({'error': 'CMS not initialized'}), 503
    
    deployment_in_progress = True
    deployment_logs.clear()
    
    thread = threading.Thread(target=harden_in_background)
    thread.daemon = True
    thread.start()
    
    return jsonify({'message': 'Security hardening started'}), 202

def harden_in_background():
    """Apply hardening in background"""
    global deployment_in_progress
    
    try:
        log_deployment("🔐 Starting security hardening...")
        cms.enhanced_security.harden_all_containers()
        log_deployment("✅ Security hardening completed!")
    except Exception as e:
        log_deployment(f"❌ Hardening failed: {str(e)}")
    finally:
        deployment_in_progress = False

# ==================== CONTAINER MANAGEMENT ====================

@app.route('/api/container/<container_name>/stop', methods=['POST'])
def stop_container(container_name):
    """Stop a container"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        container = cms.docker_client.containers.get(container_name)
        container.stop(timeout=10)
        log_deployment(f"🛑 Container {container_name} stopped")
        
        return jsonify({'message': f'Container {container_name} stopped'}), 200
    except docker.errors.NotFound:
        return jsonify({'error': f'Container {container_name} not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/container/<container_name>/start', methods=['POST'])
def start_container(container_name):
    """Start a container"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        container = cms.docker_client.containers.get(container_name)
        container.start()
        log_deployment(f"▶️ Container {container_name} started")
        
        return jsonify({'message': f'Container {container_name} started'}), 200
    except docker.errors.NotFound:
        return jsonify({'error': f'Container {container_name} not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/container/<container_name>/remove', methods=['DELETE'])
def remove_container(container_name):
    """Remove a container"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        container = cms.docker_client.containers.get(container_name)
        if container.status == 'running':
            container.stop(timeout=10)
        container.remove()
        
        return jsonify({'message': f'Container {container_name} removed'}), 200
    except docker.errors.NotFound:
        return jsonify({'error': f'Container {container_name} not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/create-client', methods=['POST'])
def create_client():
    """Create a new client container"""
    try:
        if cms is None:
            return jsonify({'error': 'CMS not initialized'}), 500
        
        data = request.get_json()
        client_name = data.get('name', 'client-pc-new') if data else 'client-pc-new'
        
        # Get next client number
        try:
            client_containers = cms.docker_client.containers.list(filters={'name': 'client-pc-'})
            next_number = len(client_containers) + 1
            final_name = f"client-pc-{next_number}"
        except:
            final_name = client_name
        
        log_deployment(f"🐳 Creating new client: {final_name}")
        
        # Deploy new client
        container = cms.docker_client.containers.run(
            "ubuntu:22.04",
            name=final_name,
            network="frontend_net",
            detach=True,
            command="tail -f /dev/null",
            restart_policy={"Name": "unless-stopped"}
        )
        
        log_deployment(f"✅ Client {final_name} created successfully")
        
        return jsonify({
            'message': f'Client {final_name} created successfully',
            'container': {
                'name': final_name,
                'id': container.id[:12],
                'status': container.status
            }
        }), 201
        
    except Exception as e:
        log_deployment(f"❌ Failed to create client: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/cleanup', methods=['POST'])
def cleanup():
    """Cleanup all infrastructure"""
    global deployment_in_progress
    
    if deployment_in_progress:
        return jsonify({'error': 'Deployment in progress'}), 400
    
    if cms is None:
        return jsonify({'error': 'CMS not initialized'}), 503
    
    try:
        log_deployment("🗑️ Cleaning up infrastructure...")
        cms.destroy_infrastructure()
        log_deployment("✅ Cleanup completed")
        
        return jsonify({'message': 'Infrastructure cleaned up'}), 200
    except Exception as e:
        log_deployment(f"❌ Cleanup failed: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/connectivity-results', methods=['GET'])
def get_connectivity_results():
    """Get connectivity test results"""
    return jsonify({
        'results': deployment_logs,
        'completed': not deployment_in_progress,
        'stats': {
            'total': len([l for l in deployment_logs if 'Testing' in l or 'SUCCESS' in l or 'FAILED' in l]),
            'passed': len([l for l in deployment_logs if 'SUCCESS' in l]),
            'failed': len([l for l in deployment_logs if 'FAILED' in l])
        },
        'system_info': {
            'containers_running': len([l for l in deployment_logs if 'deployed' in l.lower()]),
            'networks': 3,
            'duration': 'calculating...'
        },
        'issues': []
    }), 200

# ==================== VIRUSTOTAL ENDPOINTS ====================

@app.route('/api/virus-total-scan', methods=['POST'])
def virus_total_scan():
    """Scan URL or file hash using VirusTotal API"""
    try:
        data = request.json
        scan_type = data.get('scan_type', 'url')  # url or hash
        query = data.get('query', '')
        
        if not query:
            return jsonify({'success': False, 'error': 'Query parameter is required'}), 400
        
        api_key = os.getenv('VIRUS_TOTAL_API_KEY')
        if not api_key:
            return jsonify({'success': False, 'error': 'VirusTotal API key not configured'}), 500
        
        # Call VirusTotal API
        headers = {'x-apikey': api_key}
        
        if scan_type == 'url':
            # URL scanning endpoint
            url = 'https://www.virustotal.com/api/v3/urls'
            files = {'url': (None, query)}
            response = requests.post(url, files=files, headers=headers)
            
            if response.status_code != 200:
                return jsonify({'success': False, 'error': f'VirusTotal API error: {response.status_code}'}), 500
            
            result_data = response.json()
            analysis_id = result_data['data']['id']
            
            # Get detailed analysis
            analysis_url = f'https://www.virustotal.com/api/v3/analyses/{analysis_id}'
            analysis_response = requests.get(analysis_url, headers=headers)
            analysis_result = analysis_response.json()
            
            # Parse results
            stats = analysis_result['data']['attributes']['stats']
            results = parse_virustotal_results(query, stats, analysis_result['data']['attributes'], scan_type)
            
        else:  # hash
            # Hash lookup endpoint
            url = f'https://www.virustotal.com/api/v3/files/{query}'
            response = requests.get(url, headers=headers)
            
            if response.status_code == 404:
                results = {
                    'query': query,
                    'detections': 0,
                    'total_vendors': 0,
                    'scan_date': 'Never scanned',
                    'categories': ['Not in database'],
                    'vendors': []
                }
            elif response.status_code != 200:
                return jsonify({'success': False, 'error': f'VirusTotal API error: {response.status_code}'}), 500
            else:
                result_data = response.json()
                stats = result_data['data']['attributes']['last_analysis_stats']
                results = parse_virustotal_results(query, stats, result_data['data']['attributes'], scan_type)
        
        return jsonify({
            'success': True,
            'results': results
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def parse_virustotal_results(query, stats, attributes, scan_type):
    """Parse VirusTotal API response into consistent format"""
    detections = stats.get('malicious', 0)
    total = sum(stats.values()) if isinstance(stats, dict) else 0
    
    # Get vendor detections
    vendors = []
    last_analysis = attributes.get('last_analysis_results', {})
    
    for vendor, result in last_analysis.items():
        if result['category'] != 'undetected':
            vendors.append({
                'vendor': vendor,
                'detection': result.get('result', 'Detected')
            })
    
    # Get categories
    categories = []
    if 'categories' in attributes:
        categories = list(attributes['categories'].values()) if isinstance(attributes['categories'], dict) else []
    
    return {
        'query': query,
        'detections': detections,
        'total_vendors': total,
        'scan_date': attributes.get('last_analysis_date', attributes.get('last_submission_date', 'N/A')),
        'last_submission_date': attributes.get('last_submission_date'),
        'categories': categories,
        'vendors': vendors[:20],  # Limit to first 20 detections
        'meaningful_name': attributes.get('meaningful_name'),
        'size': attributes.get('size'),
        'type': attributes.get('type_description')
    }

# ==================== ABUSEIPDB ENDPOINTS ====================

@app.route('/api/abuseipdb-check', methods=['POST'])
def abuseipdb_check():
    """Check IP address reputation using AbuseIPDB API"""
    try:
        data = request.json
        ip_address = data.get('ip_address', '')
        
        if not ip_address:
            return jsonify({'success': False, 'error': 'IP address is required'}), 400
        
        api_key = os.getenv('ABUSEIPDB_API_KEY')
        if not api_key:
            return jsonify({'success': False, 'error': 'AbuseIPDB API key not configured'}), 500
        
        # Call AbuseIPDB API
        headers = {
            'Key': api_key,
            'Accept': 'application/json'
        }
        
        url = 'https://api.abuseipdb.com/api/v2/check'
        params = {
            'ipAddress': ip_address,
            'maxAgeInDays': 90,
            'verbose': ''
        }
        
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code != 200:
            return jsonify({'success': False, 'error': f'AbuseIPDB API error: {response.status_code}'}), 500
        
        result_data = response.json()
        
        if 'data' not in result_data:
            return jsonify({'success': False, 'error': 'Invalid API response'}), 500
        
        results = parse_abuseipdb_results(result_data['data'])
        
        return jsonify({
            'success': True,
            'results': results
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def parse_abuseipdb_results(data):
    """Parse AbuseIPDB API response into consistent format"""
    reports = []
    
    # Parse verbose reports if available
    if 'reports' in data and data['reports']:
        for report in data['reports'][:20]:  # Limit to 20 reports
            reports.append({
                'comment': report.get('comment', 'N/A'),
                'reported_at': report.get('reportedAt', 'N/A'),
                'reporter_id': report.get('reporterId', 'Anonymous'),
                'category': report.get('category', 'Unknown')
            })
    
    return {
        'ip_address': data.get('ipAddress', ''),
        'abuse_score': data.get('abuseConfidenceScore', 0),
        'total_reports': data.get('totalReports', 0),
        'distinct_reporters': data.get('numDistinctUsers', 0),
        'last_reported_at': data.get('lastReportedAt'),
        'isp': data.get('isp', 'Unknown'),
        'country_code': data.get('countryCode', 'Unknown'),
        'country_name': data.get('countryName', 'Unknown'),
        'hostname': data.get('hostnames', [None])[0] if data.get('hostnames') else None,
        'usage_type': data.get('usageType', 'Unknown'),
        'is_whitelisted': data.get('isWhitelisted', False),
        'labels': data.get('labels', []),
        'reports': reports
    }

# ==================== SSH MANAGEMENT ENDPOINTS ====================

@app.route('/api/ssh-containers', methods=['GET'])
def get_ssh_containers():
    """Get list of all containers with SSH access"""
    try:
        client = docker.from_env()
        containers = []
        
        # SSH port mappings
        ssh_ports = {
            'web-server-1': 2201,
            'web-server-2': 2202,
            'db-server-1': 2203,
            'email-server-1': 2204,
            'client-pc-1': 2211,
            'client-pc-2': 2212,
            'client-pc-3': 2213
        }
        
        for container_name, ssh_port in ssh_ports.items():
            try:
                container = client.containers.get(container_name)
                containers.append({
                    'name': container_name,
                    'status': container.status,
                    'ssh_port': ssh_port,
                    'host': 'localhost',
                    'service': container.labels.get('cms.service', 'unknown')
                })
            except:
                pass
        
        return jsonify({
            'success': True,
            'containers': containers
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ssh-test', methods=['POST'])
def ssh_test():
    """Test SSH connectivity to a container"""
    try:
        data = request.json
        container_name = data.get('container_name', '')
        
        if not container_name:
            return jsonify({'success': False, 'error': 'Container name required'}), 400
        
        # SSH port mappings
        ssh_ports = {
            'web-server-1': 2201,
            'web-server-2': 2202,
            'db-server-1': 2203,
            'email-server-1': 2204,
            'client-pc-1': 2211,
            'client-pc-2': 2212,
            'client-pc-3': 2213
        }
        
        if container_name not in ssh_ports:
            return jsonify({'success': False, 'error': 'Container not found'}), 404
        
        ssh_port = ssh_ports[container_name]
        
        # Test SSH connectivity using SSH key
        try:
            key_path = os.path.join(os.path.dirname(__file__), 'keys', 'id_rsa')
            result = subprocess.run(
                ['ssh', '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null',
                 '-o', 'ConnectTimeout=5', '-i', key_path, '-p', str(ssh_port),
                 'root@localhost', 'echo "SSH Connection Successful"'],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                return jsonify({
                    'success': True,
                    'message': 'SSH connection successful',
                    'container': container_name,
                    'port': ssh_port
                }), 200
            else:
                return jsonify({
                    'success': False,
                    'error': f'SSH connection failed: {result.stderr}'
                }), 500
        except subprocess.TimeoutExpired:
            return jsonify({'success': False, 'error': 'SSH connection timeout'}), 500
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/ssh-command', methods=['POST'])
def ssh_command():
    """Execute a command on a container via SSH"""
    try:
        data = request.json
        container_name = data.get('container_name', '')
        command = data.get('command', '')
        
        if not container_name or not command:
            return jsonify({'success': False, 'error': 'Container name and command required'}), 400
        
        # SSH port mappings
        ssh_ports = {
            'web-server-1': 2201,
            'web-server-2': 2202,
            'db-server-1': 2203,
            'email-server-1': 2204,
            'client-pc-1': 2211,
            'client-pc-2': 2212,
            'client-pc-3': 2213
        }
        
        if container_name not in ssh_ports:
            return jsonify({'success': False, 'error': 'Container not found'}), 404
        
        ssh_port = ssh_ports[container_name]
        
        # Execute command via SSH
        try:
            key_path = os.path.join(os.path.dirname(__file__), 'keys', 'id_rsa')
            result = subprocess.run(
                ['ssh', '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null',
                 '-i', key_path, '-p', str(ssh_port), 'root@localhost', command],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            return jsonify({
                'success': True,
                'output': result.stdout,
                'error': result.stderr if result.returncode != 0 else '',
                'exit_code': result.returncode,
                'container': container_name
            }), 200
            
        except subprocess.TimeoutExpired:
            return jsonify({'success': False, 'error': 'Command execution timeout'}), 500
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({'error': 'Server error'}), 500

@app.route('/')
def dashboard():
    """Serve enhanced dashboard"""
    return render_template('dashboard.html')

@app.route('/virus-total')
def virus_total():
    """Serve VirusTotal scanner page"""
    return render_template('virus_total.html')

@app.route('/abuseipdb')
def abuseipdb():
    """Serve AbuseIPDB checker page"""
    return render_template('abuseipdb.html')

@app.route('/ssh-manager')
def ssh_manager():
    """Serve SSH Manager page"""
    return render_template('ssh_manager.html')

if __name__ == '__main__':
    print("🚀 Initializing Enhanced CMS API...")
    if init_cms():
        print("✅ CMS initialized successfully - Full mode")
    else:
        print("⚠️ CMS initialization failed - Limited mode")
    
    print("🌐 Starting Flask server on port 5001...")
    print("📊 Dashboard: http://localhost:5001")
    app.run(debug=False, host='0.0.0.0', port=5001)

